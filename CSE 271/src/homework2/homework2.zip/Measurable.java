package homework2;

public interface Measurable {
	
	double getMeasure();
	
}
