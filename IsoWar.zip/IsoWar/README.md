<h1>Final Project for CSE 271</h1>
<h4>Nick Jarvis</h4>

<p>The idea was generated from a program that combines an art style, theme, and game genre together.
The result was "A minimalist isometric multiplayer war game with the theme: WW1"</p>

<p>The project uses slick2D for the display.</p>
