import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

public class StackRotate {
	
	public static <T> void rotate(Stack<T> stk, int n, int m){
		int realM = m % n; // Prevents m from being larger than or greater than n;
		T[] arr = (T[]) new Object[n]; // Create an array to hold the values (these are backwards now)
		for (int i = 0; i < n; i++){
			arr[i] = stk.pop();
		}
		
		// Split the array at the rotate point and combine the two in the opposite order
		// [A, B, C, D] rotated 2 times is split into [A, B] and [C, D] then combined as [C, D, A, B]
		T[] tmpF = Arrays.copyOfRange(arr, m, n);
		T[] tmpI = Arrays.copyOfRange(arr, 0, m);
		T[] tmpT = (T[]) new Object[n];
		System.arraycopy(tmpF, 0, tmpT, 0, tmpF.length);
		System.arraycopy(tmpI, 0, tmpT, tmpF.length, tmpI.length);
		
		// Now because this is backwards we need to reverse it
		List<T> backwards = Arrays.asList(tmpT);
		Collections.reverse(backwards);
		
		// Then push it back in
		for (T t : backwards){
			stk.push(t);
		}
	}
	
	public static void main(String[] args){
		Stack<Integer> a = new Stack<Integer>();
		a.push(1);
		a.push(2);
		a.push(3);
		a.push(4);
		a.push(5);
		rotate(a, 3, 2);
	}
}
